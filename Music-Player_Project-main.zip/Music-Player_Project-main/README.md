# Music-Player_Project.
Music-Player-Project (Made using HTML5 CSS3 and BOOTSTRAP)

You can see the website live at: https://5codeman.github.io/Music-Player-Project/index.html

In this project i have created front-end design of a music player in HTML and CSS to increease my command over them.

ABOUT THIS PROJECT-:

This is a simple static music player created using pure HTML and CSS as part of my MERN stack course in Coding Ninjas.

Project has 2 pages, one for home and another for single-playlist which can be accessed by clicking on any image/link of Popular Artist Section and also through the option provided in nav bar.

Although the website is mostly responsive, still it has some minor issues for smaller screens and need improvements. It will be covered in updated versions.

For demo purpose, there is only one song in this project.
